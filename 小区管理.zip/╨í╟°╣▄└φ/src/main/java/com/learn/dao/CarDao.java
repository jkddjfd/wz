package com.learn.dao;

import com.learn.entity.CarEntity;

/**
 * 车位信息
 * 

 */
public interface CarDao extends BaseDao<CarEntity> {
	
}
