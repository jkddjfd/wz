package com.learn.dao;

import com.learn.entity.SysLogEntity;

/**
 * 系统日志
 * 
 */
public interface SysLogDao extends BaseDao<SysLogEntity> {
	
}
