package com.learn.dao;

import com.learn.entity.RoomEntity;

/**
 * 房间信息
 * 
 */
public interface RoomDao extends BaseDao<RoomEntity> {
	
}
