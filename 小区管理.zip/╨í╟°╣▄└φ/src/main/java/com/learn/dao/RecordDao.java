package com.learn.dao;

import com.learn.entity.RecordEntity;

/**
 * 缴费时间
 * 
 */
public interface RecordDao extends BaseDao<RecordEntity> {
	
}
