package com.learn.dao;

import com.learn.entity.HouseEntity;

/**
 * 楼栋信息
 * 
 */
public interface HouseDao extends BaseDao<HouseEntity> {
	
}
