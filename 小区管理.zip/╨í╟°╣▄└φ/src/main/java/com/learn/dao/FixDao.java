package com.learn.dao;

import com.learn.entity.FixEntity;

/**
 * 报修信息
 * 
 */
public interface FixDao extends BaseDao<FixEntity> {
	
}
