package com.learn.dao;

import com.learn.entity.TsEntity;

/**
 * 投诉信息
 * 
 */
public interface TsDao extends BaseDao<TsEntity> {
	
}
