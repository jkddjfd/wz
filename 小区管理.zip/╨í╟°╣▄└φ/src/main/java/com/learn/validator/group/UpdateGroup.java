package com.learn.validator.group;

/**
 * 更新数据 Group

 */

public interface UpdateGroup {

}
