package com.learn.validator.group;

/**
 * 新增数据 Group
 */
public interface AddGroup {
}
