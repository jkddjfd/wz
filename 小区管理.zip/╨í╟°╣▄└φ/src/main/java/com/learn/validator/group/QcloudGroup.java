package com.learn.validator.group;

/**
 * 腾讯云

 */
public interface QcloudGroup {
}
