package com.learn.validator.group;

/**
 * 阿里云
 */
public interface AliyunGroup {
}
