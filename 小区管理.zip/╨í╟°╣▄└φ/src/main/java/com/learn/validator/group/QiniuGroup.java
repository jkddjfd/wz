package com.learn.validator.group;


public interface QiniuGroup {
}
